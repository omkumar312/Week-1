import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { 
  Download, 
  FileText, 
  FileSpreadsheet, 
  Database, 
  Calendar as CalendarIcon,
  Filter,
  Settings
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface ExportOptions {
  format: 'csv' | 'excel' | 'json' | 'pdf';
  dateRange: { from: Date; to: Date };
  dataTypes: string[];
  locations: string[];
}

export function DataExport() {
  const [isExporting, setIsExporting] = useState(false);
  const [exportOptions, setExportOptions] = useState<ExportOptions>({
    format: 'csv',
    dateRange: { 
      from: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), 
      to: new Date() 
    },
    dataTypes: ['air-quality'],
    locations: ['downtown']
  });
  const [showFromCalendar, setShowFromCalendar] = useState(false);
  const [showToCalendar, setShowToCalendar] = useState(false);
  const { toast } = useToast();

  const dataTypes = [
    { id: 'air-quality', label: 'Air Quality (AQI, PM2.5, NO2)' },
    { id: 'water-quality', label: 'Water Quality (pH, Oxygen, Temperature)' },
    { id: 'climate', label: 'Climate Data (Temperature, Humidity)' },
    { id: 'emissions', label: 'Emission Levels (CO2, CH4)' },
    { id: 'noise', label: 'Noise Pollution (dB levels)' },
    { id: 'energy', label: 'Energy Consumption' }
  ];

  const locations = [
    { id: 'downtown', label: 'Downtown Station' },
    { id: 'industrial', label: 'Industrial Zone' },
    { id: 'residential', label: 'Residential Areas' },
    { id: 'park', label: 'Central Park' },
    { id: 'river', label: 'River Monitoring Points' },
    { id: 'highway', label: 'Highway Corridors' }
  ];

  const formatOptions = [
    { value: 'csv', label: 'CSV', icon: FileText, description: 'Comma-separated values for spreadsheet applications' },
    { value: 'excel', label: 'Excel', icon: FileSpreadsheet, description: 'Microsoft Excel format with charts and formatting' },
    { value: 'json', label: 'JSON', icon: Database, description: 'JSON format for API integration and analysis' },
    { value: 'pdf', label: 'PDF Report', icon: FileText, description: 'Formatted report with charts and analysis' }
  ];

  const handleDataTypeChange = (dataTypeId: string, checked: boolean) => {
    setExportOptions(prev => ({
      ...prev,
      dataTypes: checked 
        ? [...prev.dataTypes, dataTypeId]
        : prev.dataTypes.filter(id => id !== dataTypeId)
    }));
  };

  const handleLocationChange = (locationId: string, checked: boolean) => {
    setExportOptions(prev => ({
      ...prev,
      locations: checked 
        ? [...prev.locations, locationId]
        : prev.locations.filter(id => id !== locationId)
    }));
  };

  const handleExport = async () => {
    if (exportOptions.dataTypes.length === 0) {
      toast({
        title: "Selection Required",
        description: "Please select at least one data type to export.",
        variant: "destructive",
      });
      return;
    }

    if (exportOptions.locations.length === 0) {
      toast({
        title: "Selection Required",
        description: "Please select at least one location to export.",
        variant: "destructive",
      });
      return;
    }

    setIsExporting(true);
    
    // Simulate export process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    toast({
      title: "Export Completed",
      description: `Data exported successfully as ${exportOptions.format.toUpperCase()}. Download will start shortly.`,
    });
    
    setIsExporting(false);

    // Simulate file download
    const selectedDataTypes = dataTypes.filter(dt => exportOptions.dataTypes.includes(dt.id));
    const selectedLocations = locations.filter(loc => exportOptions.locations.includes(loc.id));
    const filename = `environmental-data-${format(new Date(), 'yyyy-MM-dd')}.${exportOptions.format}`;
    
    console.log('Export completed:', {
      filename,
      format: exportOptions.format,
      dateRange: exportOptions.dateRange,
      dataTypes: selectedDataTypes.map(dt => dt.label),
      locations: selectedLocations.map(loc => loc.label)
    });
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Download className="w-5 h-5" />
          Export Environmental Data
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Export Format Selection */}
        <div>
          <Label className="text-base font-medium mb-3 block">Export Format</Label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {formatOptions.map((format) => {
              const Icon = format.icon;
              return (
                <div
                  key={format.value}
                  className={`p-4 border rounded-lg cursor-pointer transition-all ${
                    exportOptions.format === format.value
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => setExportOptions(prev => ({ ...prev, format: format.value as any }))}
                >
                  <div className="flex items-start gap-3">
                    <Icon className="w-5 h-5 mt-0.5 text-primary" />
                    <div>
                      <h4 className="font-medium">{format.label}</h4>
                      <p className="text-sm text-muted-foreground">{format.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Date Range Selection */}
        <div>
          <Label className="text-base font-medium mb-3 block">Date Range</Label>
          <div className="flex gap-4">
            <div className="flex-1">
              <Label className="text-sm text-muted-foreground">From</Label>
              <Popover open={showFromCalendar} onOpenChange={setShowFromCalendar}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(exportOptions.dateRange.from, "PPP")}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={exportOptions.dateRange.from}
                    onSelect={(date) => {
                      if (date) {
                        setExportOptions(prev => ({
                          ...prev,
                          dateRange: { ...prev.dateRange, from: date }
                        }));
                        setShowFromCalendar(false);
                      }
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="flex-1">
              <Label className="text-sm text-muted-foreground">To</Label>
              <Popover open={showToCalendar} onOpenChange={setShowToCalendar}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(exportOptions.dateRange.to, "PPP")}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={exportOptions.dateRange.to}
                    onSelect={(date) => {
                      if (date) {
                        setExportOptions(prev => ({
                          ...prev,
                          dateRange: { ...prev.dateRange, to: date }
                        }));
                        setShowToCalendar(false);
                      }
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
        </div>

        {/* Data Types Selection */}
        <div>
          <Label className="text-base font-medium mb-3 block">Data Types</Label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {dataTypes.map((dataType) => (
              <div key={dataType.id} className="flex items-center space-x-2">
                <Checkbox
                  id={dataType.id}
                  checked={exportOptions.dataTypes.includes(dataType.id)}
                  onCheckedChange={(checked) => handleDataTypeChange(dataType.id, checked as boolean)}
                />
                <Label htmlFor={dataType.id} className="text-sm font-normal">
                  {dataType.label}
                </Label>
              </div>
            ))}
          </div>
        </div>

        {/* Locations Selection */}
        <div>
          <Label className="text-base font-medium mb-3 block">Monitoring Locations</Label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {locations.map((location) => (
              <div key={location.id} className="flex items-center space-x-2">
                <Checkbox
                  id={location.id}
                  checked={exportOptions.locations.includes(location.id)}
                  onCheckedChange={(checked) => handleLocationChange(location.id, checked as boolean)}
                />
                <Label htmlFor={location.id} className="text-sm font-normal">
                  {location.label}
                </Label>
              </div>
            ))}
          </div>
        </div>

        {/* Export Summary */}
        <div className="bg-muted/50 p-4 rounded-lg">
          <h4 className="font-medium mb-2">Export Summary</h4>
          <div className="text-sm text-muted-foreground space-y-1">
            <p>Format: {formatOptions.find(f => f.value === exportOptions.format)?.label}</p>
            <p>Date Range: {format(exportOptions.dateRange.from, "MMM dd, yyyy")} - {format(exportOptions.dateRange.to, "MMM dd, yyyy")}</p>
            <p>Data Types: {exportOptions.dataTypes.length} selected</p>
            <p>Locations: {exportOptions.locations.length} selected</p>
          </div>
        </div>

        {/* Export Button */}
        <Button 
          onClick={handleExport} 
          disabled={isExporting}
          className="w-full"
          size="lg"
        >
          {isExporting ? (
            <>
              <Settings className="mr-2 h-4 w-4 animate-spin" />
              Exporting Data...
            </>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              Export Data
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}