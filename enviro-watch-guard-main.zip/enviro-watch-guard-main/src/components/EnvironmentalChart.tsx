import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Area, AreaChart } from 'recharts';

const airQualityData = [
  { time: '00:00', aqi: 45, pm25: 12, no2: 18 },
  { time: '04:00', aqi: 52, pm25: 15, no2: 22 },
  { time: '08:00', aqi: 68, pm25: 22, no2: 28 },
  { time: '12:00', aqi: 74, pm25: 28, no2: 32 },
  { time: '16:00', aqi: 58, pm25: 20, no2: 25 },
  { time: '20:00', aqi: 42, pm25: 14, no2: 19 },
];

const waterQualityData = [
  { time: 'Jan', ph: 7.2, oxygen: 8.5, temperature: 15.2 },
  { time: 'Feb', ph: 7.1, oxygen: 8.8, temperature: 16.1 },
  { time: 'Mar', ph: 7.3, oxygen: 8.2, temperature: 18.5 },
  { time: 'Apr', ph: 7.0, oxygen: 8.9, temperature: 20.3 },
  { time: 'May', ph: 7.2, oxygen: 8.6, temperature: 22.1 },
  { time: 'Jun', ph: 7.1, oxygen: 8.4, temperature: 24.8 },
];

export function EnvironmentalChart() {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Air Quality Index (24h)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={airQualityData}>
                <defs>
                  <linearGradient id="aqiGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(142 68% 45%)" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(142 68% 45%)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="time" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <Area
                  type="monotone"
                  dataKey="aqi"
                  stroke="hsl(142 68% 45%)"
                  strokeWidth={3}
                  fill="url(#aqiGradient)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="flex items-center justify-center mt-4 text-sm text-muted-foreground">
            Current AQI: <span className="ml-2 text-success font-semibold">45 - Good</span>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Water Quality Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={waterQualityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="time" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <Line 
                  type="monotone" 
                  dataKey="ph" 
                  stroke="hsl(142 68% 45%)" 
                  strokeWidth={3}
                  dot={{ fill: 'hsl(142 68% 45%)', strokeWidth: 2, r: 4 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="oxygen" 
                  stroke="hsl(200 80% 40%)" 
                  strokeWidth={3}
                  dot={{ fill: 'hsl(200 80% 40%)', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="flex items-center justify-between mt-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-primary"></div>
              <span className="text-muted-foreground">pH Level</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-secondary"></div>
              <span className="text-muted-foreground">Oxygen (mg/L)</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}