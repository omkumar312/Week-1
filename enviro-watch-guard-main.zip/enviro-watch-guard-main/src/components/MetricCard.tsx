import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

interface MetricCardProps {
  title: string;
  value: string | number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  trendValue: string;
  status: 'good' | 'moderate' | 'poor';
  icon: React.ReactNode;
}

export function MetricCard({ title, value, unit, trend, trendValue, status, icon }: MetricCardProps) {
  const getTrendIcon = () => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="w-4 h-4" />;
      case 'down':
        return <TrendingDown className="w-4 h-4" />;
      default:
        return <Minus className="w-4 h-4" />;
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'good':
        return 'text-success';
      case 'moderate':
        return 'text-warning';
      case 'poor':
        return 'text-destructive';
      default:
        return 'text-muted-foreground';
    }
  };

  const getTrendColor = () => {
    switch (trend) {
      case 'up':
        return status === 'good' ? 'text-success' : 'text-destructive';
      case 'down':
        return status === 'good' ? 'text-destructive' : 'text-success';
      default:
        return 'text-muted-foreground';
    }
  };

  return (
    <Card className="relative overflow-hidden transition-all duration-300 hover:shadow-card hover:-translate-y-1">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className={`p-2 rounded-lg bg-gradient-to-br ${
          status === 'good' ? 'from-success/20 to-success/10 text-success' :
          status === 'moderate' ? 'from-warning/20 to-warning/10 text-warning' :
          'from-destructive/20 to-destructive/10 text-destructive'
        }`}>
          {icon}
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline justify-between">
          <div>
            <div className="text-2xl font-bold flex items-baseline gap-1">
              <span className={getStatusColor()}>{value}</span>
              <span className="text-sm font-normal text-muted-foreground">{unit}</span>
            </div>
          </div>
          <div className={`flex items-center gap-1 text-xs ${getTrendColor()}`}>
            {getTrendIcon()}
            <span>{trendValue}</span>
          </div>
        </div>
        <div className="mt-3 h-1 bg-muted rounded-full overflow-hidden">
          <div 
            className={`h-full transition-all duration-500 ${
              status === 'good' ? 'bg-gradient-earth' :
              status === 'moderate' ? 'bg-gradient-to-r from-warning to-warning/60' :
              'bg-gradient-to-r from-destructive to-destructive/60'
            }`}
            style={{ 
              width: status === 'good' ? '85%' : status === 'moderate' ? '60%' : '30%' 
            }}
          />
        </div>
      </CardContent>
    </Card>
  );
}