import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { MetricCard } from "@/components/MetricCard";
import { DataExport } from "@/components/DataExport";
import { 
  Activity, 
  Wind, 
  Droplets, 
  Thermometer, 
  Leaf, 
  Zap,
  Radio,
  Pause,
  Play,
  RefreshCw,
  Download,
  MapPin,
  Clock
} from "lucide-react";

interface LiveDataPoint {
  id: string;
  location: string;
  airQuality: { value: number; status: 'good' | 'moderate' | 'poor' };
  waterQuality: { value: number; status: 'good' | 'moderate' | 'poor' };
  temperature: { value: number; status: 'good' | 'moderate' | 'poor' };
  co2: { value: number; status: 'good' | 'moderate' | 'poor' };
  lastUpdated: string;
}

const initialData: LiveDataPoint[] = [
  {
    id: '1',
    location: 'Downtown Station',
    airQuality: { value: 45, status: 'good' },
    waterQuality: { value: 7.2, status: 'good' },
    temperature: { value: 22.4, status: 'moderate' },
    co2: { value: 385, status: 'good' },
    lastUpdated: new Date().toLocaleTimeString()
  },
  {
    id: '2',
    location: 'Industrial Zone',
    airQuality: { value: 78, status: 'moderate' },
    waterQuality: { value: 6.8, status: 'moderate' },
    temperature: { value: 24.1, status: 'moderate' },
    co2: { value: 420, status: 'moderate' },
    lastUpdated: new Date().toLocaleTimeString()
  },
  {
    id: '3',
    location: 'Central Park',
    airQuality: { value: 32, status: 'good' },
    waterQuality: { value: 7.5, status: 'good' },
    temperature: { value: 21.8, status: 'good' },
    co2: { value: 350, status: 'good' },
    lastUpdated: new Date().toLocaleTimeString()
  },
  {
    id: '4',
    location: 'River Point A',
    airQuality: { value: 55, status: 'moderate' },
    waterQuality: { value: 6.5, status: 'poor' },
    temperature: { value: 19.2, status: 'good' },
    co2: { value: 395, status: 'good' },
    lastUpdated: new Date().toLocaleTimeString()
  }
];

const LiveData = () => {
  const [data, setData] = useState<LiveDataPoint[]>(initialData);
  const [isLiveUpdating, setIsLiveUpdating] = useState(true);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [lastUpdateTime, setLastUpdateTime] = useState(new Date());

  // Simulate real-time data updates
  useEffect(() => {
    if (!isLiveUpdating) return;

    const interval = setInterval(() => {
      setData(prevData => 
        prevData.map(point => ({
          ...point,
          airQuality: {
            ...point.airQuality,
            value: Math.max(20, Math.min(150, point.airQuality.value + (Math.random() - 0.5) * 10))
          },
          waterQuality: {
            ...point.waterQuality,
            value: Math.max(6.0, Math.min(8.5, point.waterQuality.value + (Math.random() - 0.5) * 0.2))
          },
          temperature: {
            ...point.temperature,
            value: Math.max(15, Math.min(35, point.temperature.value + (Math.random() - 0.5) * 2))
          },
          co2: {
            ...point.co2,
            value: Math.max(300, Math.min(500, point.co2.value + (Math.random() - 0.5) * 20))
          },
          lastUpdated: new Date().toLocaleTimeString()
        }))
      );
      setLastUpdateTime(new Date());
    }, 3000); // Update every 3 seconds

    return () => clearInterval(interval);
  }, [isLiveUpdating]);

  const handleRefresh = () => {
    // Manually refresh data
    setData(prevData => 
      prevData.map(point => ({
        ...point,
        lastUpdated: new Date().toLocaleTimeString()
      }))
    );
    setLastUpdateTime(new Date());
  };

  const getOverallStatus = () => {
    const statuses = data.flatMap(point => [
      point.airQuality.status,
      point.waterQuality.status,
      point.temperature.status,
      point.co2.status
    ]);
    
    if (statuses.includes('poor')) return 'poor';
    if (statuses.includes('moderate')) return 'moderate';
    return 'good';
  };

  const overallStatus = getOverallStatus();

  return (
    <div className="min-h-screen bg-gradient-bg-subtle p-6">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-gradient-to-br from-primary/20 to-primary/10">
                <Activity className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-foreground">Live Environmental Data</h1>
                <p className="text-muted-foreground">Real-time monitoring across all sensor stations</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Switch
                  id="live-updates"
                  checked={isLiveUpdating}
                  onCheckedChange={setIsLiveUpdating}
                />
                <Label htmlFor="live-updates" className="flex items-center gap-2">
                  {isLiveUpdating ? <Radio className="w-4 h-4 text-success animate-pulse" /> : <Pause className="w-4 h-4" />}
                  Live Updates
                </Label>
              </div>
              
              <Button variant="outline" onClick={handleRefresh}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
              
              <Button onClick={() => setShowExportDialog(!showExportDialog)}>
                <Download className="w-4 h-4 mr-2" />
                Export Data
              </Button>
            </div>
          </div>

          {/* System Overview */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-4 h-4 rounded-full ${
                    overallStatus === 'good' ? 'bg-success animate-pulse' :
                    overallStatus === 'moderate' ? 'bg-warning animate-pulse' :
                    'bg-destructive animate-pulse'
                  }`} />
                  <div>
                    <h3 className="font-semibold">System Status</h3>
                    <p className="text-sm text-muted-foreground">
                      {data.length} stations active • Overall status: {' '}
                      <span className={
                        overallStatus === 'good' ? 'text-success font-medium' :
                        overallStatus === 'moderate' ? 'text-warning font-medium' :
                        'text-destructive font-medium'
                      }>
                        {overallStatus.toUpperCase()}
                      </span>
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  Last updated: {lastUpdateTime.toLocaleTimeString()}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Export Dialog */}
        {showExportDialog && (
          <div className="mb-8">
            <DataExport />
          </div>
        )}

        {/* Live Data Stations */}
        <div className="space-y-8">
          {data.map((station) => (
            <Card key={station.id} className="overflow-hidden">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="w-5 h-5" />
                    {station.location}
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">
                      <Clock className="w-3 h-3 mr-1" />
                      {station.lastUpdated}
                    </Badge>
                    {isLiveUpdating && (
                      <Badge variant="default" className="bg-success">
                        <Radio className="w-3 h-3 mr-1 animate-pulse" />
                        LIVE
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <MetricCard
                    title="Air Quality Index"
                    value={Math.round(station.airQuality.value)}
                    unit="AQI"
                    trend={station.airQuality.value > 50 ? 'up' : 'down'}
                    trendValue={`${Math.abs(Math.round((station.airQuality.value - 50) / 50 * 100))}% from baseline`}
                    status={station.airQuality.status}
                    icon={<Wind className="w-5 h-5" />}
                  />
                  
                  <MetricCard
                    title="Water Quality"
                    value={station.waterQuality.value.toFixed(1)}
                    unit="pH"
                    trend={station.waterQuality.value > 7 ? 'up' : station.waterQuality.value < 7 ? 'down' : 'stable'}
                    trendValue={station.waterQuality.value === 7 ? 'Neutral' : station.waterQuality.value > 7 ? 'Alkaline' : 'Acidic'}
                    status={station.waterQuality.status}
                    icon={<Droplets className="w-5 h-5" />}
                  />
                  
                  <MetricCard
                    title="Temperature"
                    value={station.temperature.value.toFixed(1)}
                    unit="°C"
                    trend={station.temperature.value > 23 ? 'up' : 'down'}
                    trendValue={`${Math.abs(Math.round((station.temperature.value - 22) * 10))/10}°C from avg`}
                    status={station.temperature.status}
                    icon={<Thermometer className="w-5 h-5" />}
                  />
                  
                  <MetricCard
                    title="CO₂ Levels"
                    value={Math.round(station.co2.value)}
                    unit="ppm"
                    trend={station.co2.value > 400 ? 'up' : 'down'}
                    trendValue={`${Math.abs(Math.round((station.co2.value - 380) / 380 * 100))}% from baseline`}
                    status={station.co2.status}
                    icon={<Leaf className="w-5 h-5" />}
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5" />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button variant="outline" className="h-auto p-4 justify-start">
                <div className="text-left">
                  <div className="font-medium">Set Alert Thresholds</div>
                  <div className="text-sm text-muted-foreground">Configure monitoring alerts</div>
                </div>
              </Button>
              
              <Button variant="outline" className="h-auto p-4 justify-start">
                <div className="text-left">
                  <div className="font-medium">Generate Report</div>
                  <div className="text-sm text-muted-foreground">Create detailed analysis</div>
                </div>
              </Button>
              
              <Button variant="outline" className="h-auto p-4 justify-start">
                <div className="text-left">
                  <div className="font-medium">Historical Trends</div>
                  <div className="text-sm text-muted-foreground">View long-term patterns</div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default LiveData;