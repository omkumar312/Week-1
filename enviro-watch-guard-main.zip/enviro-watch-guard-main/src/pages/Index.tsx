import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MetricCard } from "@/components/MetricCard";
import { EnvironmentalChart } from "@/components/EnvironmentalChart";
import { 
  Wind, 
  Droplets, 
  Thermometer, 
  Leaf, 
  Activity, 
  BarChart3,
  Shield,
  Zap,
  AlertTriangle
} from "lucide-react";
import heroImage from "@/assets/environmental-hero.jpg";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-bg-subtle pt-0">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-hero/90" />
        </div>
        
        <div className="relative container mx-auto px-4 py-20 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold text-primary-foreground mb-6 leading-tight">
              Environmental
              <span className="block bg-gradient-to-r from-accent to-primary-glow bg-clip-text text-transparent">
                Monitoring
              </span>
              System
            </h1>
            <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl mx-auto leading-relaxed">
              Real-time monitoring and analysis of air quality, water pollution, and environmental health indicators for a sustainable future.
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Button variant="hero" size="lg" className="group" asChild>
                <a href="/live-data">
                  <Activity className="mr-2 group-hover:rotate-12 transition-transform" />
                  View Live Data
                </a>
              </Button>
              <Button variant="outline" size="lg" className="bg-white/10 text-white border-white/30 hover:bg-white/20 hover:text-white" asChild>
                <a href="/reports">
                  <BarChart3 className="mr-2" />
                  Generate Report
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Dashboard Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Environmental Dashboard
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Monitor key environmental indicators in real-time across multiple locations and parameters.
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <MetricCard
            title="Air Quality Index"
            value={45}
            unit="AQI"
            trend="down"
            trendValue="8% from yesterday"
            status="good"
            icon={<Wind className="w-5 h-5" />}
          />
          
          <MetricCard
            title="Water Quality"
            value={7.2}
            unit="pH"
            trend="stable"
            trendValue="Optimal range"
            status="good"
            icon={<Droplets className="w-5 h-5" />}
          />
          
          <MetricCard
            title="Temperature"
            value={22.4}
            unit="°C"
            trend="up"
            trendValue="1.2°C above avg"
            status="moderate"
            icon={<Thermometer className="w-5 h-5" />}
          />
          
          <MetricCard
            title="CO₂ Levels"
            value={385}
            unit="ppm"
            trend="down"
            trendValue="3% reduction"
            status="good"
            icon={<Leaf className="w-5 h-5" />}
          />
        </div>

        {/* Charts Section */}
        <div className="mb-12">
          <EnvironmentalChart />
        </div>

        {/* Additional Information Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="shadow-card hover:shadow-glow transition-all duration-300">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-success">
                <Shield className="w-5 h-5" />
                System Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">
                All monitoring stations are operational and collecting data normally.
              </p>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
                <span className="text-sm font-medium text-success">Online</span>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-card hover:shadow-glow transition-all duration-300">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-secondary">
                <Zap className="w-5 h-5" />
                Energy Efficiency
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">
                Current energy consumption is 15% below the monthly average.
              </p>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-secondary rounded-full"></div>
                <span className="text-sm font-medium text-secondary">Optimized</span>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-card hover:shadow-glow transition-all duration-300" role="button" tabIndex={0}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-warning">
                <AlertTriangle className="w-5 h-5" />
                Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">
                2 minor alerts requiring attention in the next 24 hours.
              </p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-warning rounded-full"></div>
                  <span className="text-sm font-medium text-warning">Monitor</span>
                </div>
                <Button variant="outline" size="sm" asChild>
                  <a href="/alerts">View All</a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Index;