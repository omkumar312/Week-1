import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  FileText, 
  TrendingUp, 
  Calendar, 
  Download, 
  Eye,
  Plus,
  Filter,
  Search,
  Clock,
  CheckCircle,
  AlertTriangle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Report {
  id: string;
  title: string;
  description: string;
  type: 'monthly' | 'weekly' | 'custom' | 'compliance';
  status: 'completed' | 'generating' | 'scheduled';
  createdDate: string;
  period: string;
  format: string;
  size: string;
}

const mockReports: Report[] = [
  {
    id: '1',
    title: 'Monthly Environmental Summary',
    description: 'Comprehensive overview of all environmental metrics for January 2024',
    type: 'monthly',
    status: 'completed',
    createdDate: '2024-01-31',
    period: 'January 2024',
    format: 'PDF',
    size: '2.4 MB'
  },
  {
    id: '2',
    title: 'Air Quality Compliance Report',
    description: 'EPA compliance analysis for Q4 2023',
    type: 'compliance',
    status: 'completed',
    createdDate: '2024-01-15',
    period: 'Q4 2023',
    format: 'PDF',
    size: '1.8 MB'
  },
  {
    id: '3',
    title: 'Weekly Water Quality Analysis',
    description: 'Detailed water quality assessment for all monitoring points',
    type: 'weekly',
    status: 'generating',
    createdDate: '2024-01-14',
    period: 'Week 2, 2024',
    format: 'Excel',
    size: 'Processing...'
  },
  {
    id: '4',
    title: 'Temperature Trend Analysis',
    description: 'Custom report analyzing temperature patterns over the last 6 months',
    type: 'custom',
    status: 'scheduled',
    createdDate: '2024-01-13',
    period: 'Jul 2023 - Dec 2023',
    format: 'PDF',
    size: 'Scheduled'
  }
];

const Reports = () => {
  const [reports, setReports] = useState<Report[]>(mockReports);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newReport, setNewReport] = useState({
    title: '',
    description: '',
    type: 'custom',
    period: '',
    format: 'pdf'
  });
  const { toast } = useToast();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'default';
      case 'generating': return 'secondary';
      case 'scheduled': return 'outline';
      default: return 'default';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'generating': return <Clock className="w-4 h-4 animate-spin" />;
      case 'scheduled': return <Calendar className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'monthly': return 'bg-blue-100 text-blue-800';
      case 'weekly': return 'bg-green-100 text-green-800';
      case 'custom': return 'bg-purple-100 text-purple-800';
      case 'compliance': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleCreateReport = () => {
    if (!newReport.title || !newReport.description) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const report: Report = {
      id: (reports.length + 1).toString(),
      title: newReport.title,
      description: newReport.description,
      type: newReport.type as any,
      status: 'generating',
      createdDate: new Date().toISOString().split('T')[0],
      period: newReport.period || 'Current',
      format: newReport.format.toUpperCase(),
      size: 'Processing...'
    };

    setReports([report, ...reports]);
    setNewReport({
      title: '',
      description: '',
      type: 'custom',
      period: '',
      format: 'pdf'
    });
    setShowCreateDialog(false);

    toast({
      title: "Report Generation Started",
      description: "Your report is being generated and will be available shortly.",
    });

    // Simulate report completion
    setTimeout(() => {
      setReports(prev => 
        prev.map(r => 
          r.id === report.id 
            ? { ...r, status: 'completed' as const, size: '1.5 MB' }
            : r
        )
      );
      toast({
        title: "Report Ready",
        description: `${report.title} has been generated successfully.`,
      });
    }, 5000);
  };

  const filteredReports = reports.filter(report => {
    const matchesSearch = report.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         report.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || report.type === filterType;
    const matchesStatus = filterStatus === 'all' || report.status === filterStatus;
    
    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-gradient-bg-subtle p-6">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-gradient-to-br from-secondary/20 to-secondary/10">
              <FileText className="w-6 h-6 text-secondary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">Environmental Reports</h1>
              <p className="text-muted-foreground">Generate and manage environmental monitoring reports</p>
            </div>
          </div>
          
          <Button onClick={() => setShowCreateDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Create Report
          </Button>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Search reports..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full md:w-[160px]">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                  <SelectItem value="compliance">Compliance</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full md:w-[160px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="generating">Generating</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Create Report Dialog */}
        {showCreateDialog && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Create New Report</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="title">Report Title *</Label>
                <Input
                  id="title"
                  value={newReport.title}
                  onChange={(e) => setNewReport(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Enter report title..."
                />
              </div>
              
              <div>
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  value={newReport.description}
                  onChange={(e) => setNewReport(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Enter report description..."
                  rows={3}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="type">Report Type</Label>
                  <Select value={newReport.type} onValueChange={(value) => setNewReport(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="custom">Custom</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="compliance">Compliance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="period">Time Period</Label>
                  <Input
                    id="period"
                    value={newReport.period}
                    onChange={(e) => setNewReport(prev => ({ ...prev, period: e.target.value }))}
                    placeholder="e.g., January 2024"
                  />
                </div>
                
                <div>
                  <Label htmlFor="format">Format</Label>
                  <Select value={newReport.format} onValueChange={(value) => setNewReport(prev => ({ ...prev, format: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">PDF</SelectItem>
                      <SelectItem value="excel">Excel</SelectItem>
                      <SelectItem value="csv">CSV</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex gap-2 pt-4">
                <Button onClick={handleCreateReport}>
                  Create Report
                </Button>
                <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Reports List */}
        <div className="space-y-4">
          {filteredReports.map((report) => (
            <Card key={report.id} className="hover:shadow-card transition-all duration-300">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold">{report.title}</h3>
                      <Badge variant={getStatusColor(report.status)} className="flex items-center gap-1">
                        {getStatusIcon(report.status)}
                        {report.status.toUpperCase()}
                      </Badge>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(report.type)}`}>
                        {report.type.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-muted-foreground mb-3">{report.description}</p>
                    <div className="flex items-center gap-6 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        Created: {new Date(report.createdDate).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        Period: {report.period}
                      </div>
                      <div className="flex items-center gap-1">
                        <FileText className="w-4 h-4" />
                        {report.format} • {report.size}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    {report.status === 'completed' && (
                      <>
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4 mr-2" />
                          Preview
                        </Button>
                        <Button size="sm">
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </Button>
                      </>
                    )}
                    {report.status === 'scheduled' && (
                      <Button variant="outline" size="sm">
                        <Calendar className="w-4 h-4 mr-2" />
                        Reschedule
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredReports.length === 0 && (
          <Card>
            <CardContent className="pt-12 pb-12 text-center">
              <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No reports found</h3>
              <p className="text-muted-foreground mb-4">
                {searchTerm || filterType !== 'all' || filterStatus !== 'all' 
                  ? 'No reports match your current filters.'
                  : 'Get started by creating your first environmental report.'}
              </p>
              <Button onClick={() => setShowCreateDialog(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Report
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Reports;